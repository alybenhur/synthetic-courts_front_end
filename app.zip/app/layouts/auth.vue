<template>
  <v-app>
    <v-main class="auth-bg">
      <v-container
        fluid
        class="d-flex align-center justify-center"
        style="min-height: 100vh"
      >
        <div class="auth-wrapper">
          <!-- Logo / Brand -->
          <div class="text-center mb-6">
            <v-icon size="56" color="primary" class="mb-2">mdi-soccer-field</v-icon>
            <h1 class="text-h5 font-weight-bold text-primary">Canchas Sintéticas</h1>
            <p class="text-caption text-medium-emphasis">Sistema de Reservas</p>
          </div>
          <slot />
        </div>
      </v-container>
    </v-main>
  </v-app>
</template>

<style scoped>
.auth-bg {
  background: linear-gradient(135deg, #e3f0ff 0%, #f0f7ff 50%, #e8f5e9 100%);
}
.auth-wrapper {
  width: 100%;
  max-width: 440px;
}
</style>
